package page;

import org.openqa.selenium.By;

public class elementos {
	
	private By openModalbutton = By.cssSelector("#main > button");
	private By modal = By.cssSelector("#id01 > div > header > h2");
	private By closeModal = By.cssSelector("#id01 > div > header > span");
	
	public By getOpenModalbutton() {
		return openModalbutton;
	}
	public By getModal() {
		return modal;
	}
	public By getCloseModal() {
		return closeModal;
	}

}
