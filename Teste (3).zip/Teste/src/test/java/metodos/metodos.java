package metodos;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class metodos {
	
	WebDriver driver;
	
	public void abrirNavegador () {
		System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/howto/howto_css_modals.asp");
		driver.manage().window().maximize();
			
		
	}
	
	public void clicar(By elemento) {
		driver.findElement(elemento).click();
	}

	public void fecharNavegador() {
		driver.quit();
	}
	
	public  void print(String fileName, WebDriver driver) throws IOException {
		TakesScreenshot scrShot = (TakesScreenshot) driver;
		java.io.File scrFile = scrShot.getScreenshotAs(OutputType.FILE);
		java.io.File destFile = new java.io.File("./Evidencias/" + fileName + ".png");
		FileUtils.copyFile(scrFile, destFile);

	}
	
	public void assertTrue(By modal, String string) {
			
	}
	
	public void assertFalse(By modal, String string) {
		
	}

}

