package steps;

import static org.junit.Assert.assertNotEquals;

import java.io.IOException;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import metodos.metodos;
import page.elementos;

public class steps extends metodos {
	
	metodos metodo = new metodos ();
	elementos elemento = new elementos (); 
	

	@Given("que o usuario esteja no site")
	public void que_o_usuario_esteja_no_site() {
		metodo.abrirNavegador();
	}

	@Given("o usuario clica em abrir modal")
	public void o_usuario_clica_em_abrir_modal() {
		metodo.clicar(elemento.getOpenModalbutton());
	}

	@Given("o usuario ve o modal aberto")
	public void o_usuario_ve_o_modal_aberto() {
		metodo.assertTrue(elemento.getModal(), "Modal Header");

	  
	}

	@When("o usuario clica em fechar o modal")
	public void o_usuario_clicar_em_fechar_o_modal() {
		metodo.clicar(elemento.getCloseModal());
	    
	}

	@Then("valido se o modal esta fechado")
	public void valido_se_o_modal_esta_fechado() throws IOException {
		assertNotEquals(elemento.getModal(), "Modal Header");
		metodo.fecharNavegador();
		
	   
	}
}


